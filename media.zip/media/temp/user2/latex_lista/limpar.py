import os

def limpar_arquivos():
    # Lista de extensões para excluir
    extensoes = ['.log', '.aux', '.gz']
    
    # Obtém a lista de arquivos no diretório atual
    arquivos = os.listdir('.')
    
    # Contador de arquivos excluídos
    arquivos_excluidos = 0
    
    # Percorre cada arquivo no diretório
    for arquivo in arquivos:
        # Verifica se o arquivo termina com alguma das extensões
        if any(arquivo.endswith(ext) for ext in extensoes):
            try:
                os.remove(arquivo)
                print(f"Arquivo excluído: {arquivo}")
                arquivos_excluidos += 1
            except Exception as e:
                print(f"Erro ao excluir {arquivo}: {str(e)}")
    
    # Exibe o total de arquivos excluídos
    print(f"\nTotal de arquivos excluídos: {arquivos_excluidos}")

if __name__ == "__main__":
    limpar_arquivos()
