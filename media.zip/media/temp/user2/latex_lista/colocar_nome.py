from PyPDF2 import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from io import BytesIO
import shutil
import os

def adicionar_nome_no_pdf(filename_base, input_pdf, output_pdf, turma_estudante, coordenadas, n_chamada):
    # Cria um objeto de leitura do arquivo PDF de entrada
    reader = PdfReader(input_pdf)
    writer = PdfWriter()

    # Cria um buffer de memória para o PDF gerado com o nome
    buffer = BytesIO()
    
    # Cria um PDF com o nome e turma
    c = canvas.Canvas(buffer)
    c.setFont("Helvetica", 12)
    if filename_base == 'lista':
        c.drawString(coordenadas['nome_x'], coordenadas['y'], turma_estudante.estudante.first_name)  # Posição do texto 
        c.drawString(coordenadas['turma_x'], coordenadas['y'], f'{turma_estudante.turma.numero}ª Série {turma_estudante.turma.letra}')  # Posição do texto 
    elif filename_base == 'av_discursiva':
        c.drawString(coordenadas['nome_x'], coordenadas['y'], turma_estudante.estudante.first_name)  # Posição do texto 
        c.drawString(coordenadas['nmero_x'], coordenadas['y'], n_chamada)  # Posição do texto 
        c.drawString(coordenadas['turma_x'], coordenadas['y'], turma_estudante.turma.letra)  # Posição do texto 
    c.save()

    # Vai para o início do buffer
    buffer.seek(0)

    # Lê o PDF com o nome adicionado
    nome_pdf = PdfReader(buffer)

    # Adiciona as páginas do PDF original e sobrepõe o nome na primeira página
    n_pages = len(reader.pages)
    for i in range(n_pages):
        page = reader.pages[i]
        if i == 0:
            # Sobrepõe a primeira página com o nome
            page.merge_page(nome_pdf.pages[0])
        writer.add_page(page)

    # Se o número de páginas for ímpar e maior que 1, adiciona blank.pdf na última página
    if n_pages % 2 != 0 and n_pages > 1:
        blank_pdf = PdfReader('blank.pdf')
        writer.add_page(blank_pdf.pages[0])

    # Salva o novo arquivo PDF com o nome
    with open(output_pdf, "wb") as output_file:
        writer.write(output_file)

def copiar_arquivo(origem, destino):
    shutil.copy2(origem, destino)

def colocar_nome(turma_estudante, user_latex_dir, filename_base, n_chamada):
    # Caminhos dos arquivos
    caminho_origem = os.path.join(user_latex_dir, f"{filename_base}.pdf")
    caminho_destino = os.path.join(user_latex_dir, f"{filename_base}_{turma_estudante.estudante.id}.pdf")

    # Passo 1: Copiar o arquivo original
    copiar_arquivo(caminho_origem, caminho_destino)

    # Passo 2: Adicionar o nome 
    if filename_base == 'lista':
        coordenadas = {
            'nome_x': 76,
            'turma_x': 456,
            'y': 780.8
        }
    elif filename_base == 'av_discursiva':
        coordenadas = {
            'nome_x': 77,
            'nmero_x': 340,
            'turma_x': 416,
            'y': 740
        }
    elif filename_base == 'av_objetiva':
        coordenadas = {
            'x': 76, # ainda falta descobrir as coordenadas
            'y': 780.8
        }
    else:
        return None
    adicionar_nome_no_pdf(filename_base, caminho_origem, caminho_destino, turma_estudante, coordenadas, n_chamada)