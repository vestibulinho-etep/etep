import os
import subprocess
import glob

def compilar_latex(arquivo):
    print(f"Compilando {arquivo}...")
    subprocess.run(['pdflatex', arquivo], check=True)
    print(f"Compilação de {arquivo} concluída!")

def limpar_arquivos_auxiliares():
    extensoes = ['.aux', '.log', '.synctex.gz']
    for ext in extensoes:
        arquivos = glob.glob(f'*{ext}')
        for arquivo in arquivos:
            try:
                os.remove(arquivo)
                print(f"Arquivo {arquivo} removido com sucesso!")
            except Exception as e:
                print(f"Erro ao remover {arquivo}: {e}")

def main():
    # Obtém todos os arquivos .tex
    arquivos_latex = glob.glob('*.tex')
    # Remove o arquivo header.tex da lista
    arquivos_latex = [arquivo for arquivo in arquivos_latex if arquivo != 'header.tex']
    
    for arquivo in arquivos_latex:
        compilar_latex(arquivo)
    
    print("\nLimpando arquivos auxiliares...")
    limpar_arquivos_auxiliares()
    print("\nProcesso concluído!")

if __name__ == "__main__":
    main()