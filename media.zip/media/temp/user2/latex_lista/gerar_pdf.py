import subprocess
import os
import pandas as pd
from PyPDF2 import PdfMerger
from colocar_nome import colocar_nome
from dataclasses import dataclass

@dataclass
class Estudante:
    id: int
    first_name: str

@dataclass
class Turma:
    numero: str
    letra: str

@dataclass
class TurmaEstudante:
    estudante: Estudante
    turma: Turma

def limpar():
    """
    Remove todos os arquivos com extensões aux, log ou out no diretório atual.
    """
    for ext in ['aux', 'log', 'out']:
        for arquivo in os.listdir('.'):
            if arquivo.endswith(f'.{ext}'):
                try:
                    os.remove(arquivo)
                except OSError as e:
                    print(f"Erro ao excluir {arquivo}: {e}")

def juntar_pdfs_por_turma(pdfs_gerados, turma_letra, file_name):
    """
    Junta todos os PDFs de uma mesma turma em um único arquivo
    """
    print(f"\nJuntando PDFs da turma {turma_letra}...")
    merger = PdfMerger()
    
    for pdf in pdfs_gerados:
        merger.append(pdf)
    
    # Salva o PDF final com o nome da turma
    merger.write(f"{file_name}_{turma_letra}.pdf")
    merger.close()
    print(f"PDF da turma {turma_letra} gerado com sucesso!")
    
    # Remove os PDFs individuais
    print("Removendo PDFs individuais...")
    for pdf in pdfs_gerados:
        try:
            os.remove(pdf)
        except OSError as e:
            print(f"Erro ao excluir {pdf}: {e}")

def gerar_pdfs_individuais(file_name):
    """
    Gera PDFs individuais para cada estudante de cada turma
    """
    print("\nIniciando geração de PDFs individuais...")
    turmas_dir = 'turmas'
    pdfs_por_turma = {}
    
    # Conta total de turmas para feedback
    total_turmas = len([f for f in os.listdir(turmas_dir) if f.endswith('.csv')])
    turma_atual = 0
    
    for arquivo in os.listdir(turmas_dir):
        if arquivo.endswith('.csv'):
            turma_atual += 1
            turma_letra = arquivo.split('.')[0]
            numero = turma_letra[0]
            letra = turma_letra[1]
            
            print(f"\nProcessando turma {turma_letra} ({turma_atual}/{total_turmas})")
            pdfs_por_turma[turma_letra] = []
            
            # Lê o arquivo CSV
            df = pd.read_csv(os.path.join(turmas_dir, arquivo))
            total_alunos = len(df)
            
            print(f"Encontrados {total_alunos} alunos na turma {turma_letra}")
            
            # Para cada estudante na turma
            for idx, row in df.iterrows():
                estudante = Estudante(id=idx+1, first_name=row['nome'])
                turma = Turma(numero=numero, letra=letra)
                turma_estudante = TurmaEstudante(estudante=estudante, turma=turma)
                
                print(f"Gerando PDF para {estudante.first_name} ({idx+1}/{total_alunos})", end='\r')
                
                colocar_nome(turma_estudante, '.', 'lista', str(idx+1))
                
                pdf_gerado = f'lista_{estudante.id}.pdf'
                pdfs_por_turma[turma_letra].append(pdf_gerado)
            
            print(f"\nTodos os PDFs individuais da turma {turma_letra} foram gerados!")
            juntar_pdfs_por_turma(pdfs_por_turma[turma_letra], turma_letra, file_name)

def gerar_pdf(file_name):
    try:
        print("Iniciando geração do PDF base com LaTeX...")
        subprocess.run(['pdflatex', 'lista.tex'], check=True)
        print("PDF base gerado com sucesso!")
        
        print("\nLimpando arquivos auxiliares...")
        limpar()
        print("Arquivos auxiliares removidos!")
        
        print("\nIniciando processo de personalização dos PDFs...")
        gerar_pdfs_individuais(file_name)

        print("\nProcesso finalizado com sucesso!")
        print("PDFs gerados e separados por turma!")
    except subprocess.CalledProcessError as e:
        print(f"Erro ao gerar o PDF: {e}")
    except FileNotFoundError:
        print("Erro: pdflatex não encontrado. Verifique se o LaTeX está instalado corretamente.")
    except Exception as e:
        print(f"Erro inesperado: {e}")

if __name__ == "__main__":
    gerar_pdf('file_name')
